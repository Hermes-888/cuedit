/*
    JSON foods list
    16 good, 15 allergens
*/
var cards = {"food":[
    {"name":"Carrot", "allergen":false, "image":"images/carrot.png", "info":"Good Job, Allergen Free"},
    {"name":"Turnip", "allergen":false, "image":"images/turnip.png", "info":"Good Job, Allergen Free"},
    {"name":"Corn", "allergen":false, "image":"images/corn.png", "info":"Good Job, Allergen Free"},
    {"name":"Sunflower Seeds", "allergen":false, "image":"images/sunflowers.png", "info":"Good Job, Allergen Free"},
    {"name":"Onions", "allergen":false, "image":"images/onions.png", "info":"Good Job, Allergen Free"},
    {"name":"Celery", "allergen":false, "image":"images/celery.png", "info":"Good Job, Allergen Free"},
    {"name":"Cabbage", "allergen":false, "image":"images/blank.png", "info":"Good Job, Allergen Free"},
    {"name":"Rice", "allergen":false, "image":"images/blank.png", "info":"Good Job, Allergen Free"},
    {"name":"Garlic", "allergen":false, "image":"images/blank.png", "info":"Good Job, Allergen Free"},
    {"name":"Tomatoes", "allergen":false, "image":"images/blank.png", "info":"Good Job, Allergen Free"},
    {"name":"Potatoes", "allergen":false, "image":"images/blank.png", "info":"Good Job, Allergen Free"},
    {"name":"Peppers", "allergen":false, "image":"images/blank.png", "info":"Good Job, Allergen Free"},
    {"name":"Chicken", "allergen":false, "image":"images/blank.png", "info":"Good Job, Allergen Free"},
    {"name":"Bacon", "allergen":false, "image":"images/blank.png", "info":"Good Job, Allergen Free"},
    {"name":"Pork", "allergen":false, "image":"images/blank.png", "info":"Good Job, Allergen Free"},
    {"name":"Beef", "allergen":false, "image":"images/blank.png", "info":"Good Job, Allergen Free"},
    {"name":"Almonds", "allergen":true, "image":"images/almonds.png", "info":"Nuts represent one of the most important group of food allergens worldwide."},
    {"name":"Peanuts", "allergen":true, "image":"images/peanuts.png", "info":"Symptoms of peanut allergy range from relative mild and local responses to life threatening systemic reactions (e.g. asthma, anaphylaxis) that require emergency treatment."},
    {"name":"Eggs", "allergen":true, "image":"images/eggs.png", "info":"Symptoms of hens' egg allergy are frequently manifested as reactions of the digestive system. Often the first skin reactions are observed only minutes after consumption."},
    {"name":"Soy Beans", "allergen":true, "image":"images/soybeans.png", "info":"Soybean and its products are widely used in food stuff, not only as a food (e.g. tofu) but also as a technological aid (e.g. emulsifiers, texturizer). Soy allergy is much less prevalent than peanut allergy."},
    {"name":"Oysters", "allergen":true, "image":"images/oysters.png", "info":"Symptoms of crustacean shellfish allergy range from mild local reactions in the mouth to severe life threatening systemic reactions."},
    {"name":"Swiss Cheese", "allergen":true, "image":"images/swisscheese.png", "info":"Dairy allergies also apply to cheese"},
    {"name":"Shrimp", "allergen":true, "image":"images/blank.png", "info":"Shellfish retains its allergenic potential even after heating, avoidance of all forms of shellfish is essential. "},
    {"name":"Walnuts", "allergen":true, "image":"images/blank.png", "info":"Allergy to nuts often involves severe multisystemic and respiratory symptoms and occasionally fatal anaphylactic reactions."},
    {"name":"Dairy Cream", "allergen":true, "image":"images/blank.png", "info":"Allergy to milk proteins usually results in a combination of different symptoms often in the gastrointestinal tract, the skin and the airways within the first hour after consumption."},
    {"name":"Milk", "allergen":true, "image":"images/blank.png", "info":"Milk is a frequent cause of allergy worldwide. The most problematic milk allergens are the most abundant proteins in milk and include caseins and the whey proteins alpha-lactalbumin and beta-lactoglobulin."},
    {"name":"Pecans", "allergen":true, "image":"images/blank.png", "info":"Nuts represent one of the most important group of food allergens worldwide."},
    {"name":"Yogurt", "allergen":true, "image":"images/blank.png", "info":"Yogurt contains milk, the broad usage of cow's milk in a range of different food (e.g. baking goods, instant soups, seasonings, chocolate, and margarine) represents a challenge to milk allergic consumers to avoid."},
    {"name":"Halibut", "allergen":true, "image":"images/blank.png", "info":"Symptoms of allergic reactions to fish are skin and gastrointestinal reactions occurring shortly after ingestion."},
    {"name":"Soy Sauce", "allergen":true, "image":"images/blank.png", "info":"Symptoms of allergy to soy are similar to peanut and range from relative mild reaction to life threatening system reactions."},
    {"name":"Flour", "allergen":true, "image":"images/blank.png", "info":"Some indications of an allergy to wheat — stomach cramps, diarrhea and other gastrointestinal symptoms — overlap with those produced by a sensitivity to gluten or by celiac disease, an autoimmune disorder, so it’s crucial to get an accurate diagnosis."},
    
]};